Do not ask Dirk for help with my files. Just drop them into inventory and paste over Dirk's original PNG.

jim-g